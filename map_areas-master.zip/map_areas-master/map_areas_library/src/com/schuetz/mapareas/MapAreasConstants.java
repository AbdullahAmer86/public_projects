package com.schuetz.mapareas;

/**
 * Constants
 * 
 * @author ivanschuetz 
 */
public class MapAreasConstants {
    public static final double RADIUS_OF_EARTH_METERS = 6371009;
    
}
